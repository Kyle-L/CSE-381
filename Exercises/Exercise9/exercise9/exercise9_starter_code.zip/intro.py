#!/usr/bin/python

if __name__ == '__main__':
    print("Hello from Python.");
    print("While consuming a lot of energy, of course.");

# End of script
